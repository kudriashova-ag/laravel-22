<h1><?php echo e($title); ?></h1>
<h2><?php echo $subtitle; ?></h2>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div><?php echo e($loop->iteration); ?>. <?php echo e($user); ?></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\OSPanel\domains\laravel-22\resources\views/index.blade.php ENDPATH**/ ?>